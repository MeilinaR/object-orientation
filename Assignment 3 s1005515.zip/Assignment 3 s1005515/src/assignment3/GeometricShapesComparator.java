/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Comparator;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class GeometricShapesComparator implements Comparator<GeometricShapes> {
    private char c;

    public GeometricShapesComparator(char c) {
        this.c = c;
    }

    public GeometricShapesComparator() {
        this.c = 'a';
    }
    
     /**
     * If one of the objects is null then there is no object and it also 
     * can't be compared so then the function returns 0.If the given character 
     * is x it sorts on most left object. If the given character is y it sorts 
     * on lowest object.If the given character is a then it sorts on area and 
     * calls the compareTo in circle and rectangle
     * @param o1
     * @param o2
     * @return int -1,1,0 used to sort
     */
    public int compare(GeometricShapes o1, GeometricShapes o2) {
       if(o1 == null || o2 == null) {
           return 0;
       }
       if(c=='x') {
           return doX(o1,o2);
       }
       if(c=='y') {
           return doY(o1,o2);
       }
       if(c=='a') {
           return o1.compareTo(o2);
       }
       return 0;
    }
    
    /**
     * compareTo function for sorting on the most left object
     * @param o1
     * @param o2
     * @return -1, 0 or 1
     */
    public int doX(GeometricShapes o1, GeometricShapes o2) {
        if((o1.getLeft() - o2.getLeft()) > 0) {
            return 1;
        } else if ((o1.getLeft() - o2.getLeft()) < 0) {
            return -1;
        } else {
            return 0;
        }
        
    }
    
    /**
     * compareTo function for sorting on the lowest object
     * @param o1
     * @param o2
     * @return -1, 0 or 1
     */
    public int doY(GeometricShapes o1, GeometricShapes o2) {
        if((o1.getBottom() - o2.getBottom()) > 0) {
            return 1;
        } else if ((o1.getBottom() - o2.getBottom()) < 0) {
            return -1;
        } else {
            return 0;
        }
        
    }
    
}
