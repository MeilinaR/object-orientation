/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public interface GeometricShapes extends Comparable<GeometricShapes> {
    public double getLeft();
    public double getRight();
    public double getBottom();
    public double getTop();
    public double area();
    public void move(double dx, double dy);
    
}
