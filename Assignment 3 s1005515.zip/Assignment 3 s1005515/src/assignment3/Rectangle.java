/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Rectangle implements GeometricShapes {
    private double x, y, h, w;
    
    public Rectangle(int x, int y, int h, int w) {
        this.x = x;
        this.y = y;
        this.h = h;
        this.w = w;
    }
    
    private double getX() {
        return x;
    }
 
    private void setX(double x) {
        this.x = x;
    }
    
    private double getY() {
        return y;
    }
    
  
    private void setY(double y) {
        this.y = y;
    }

    private double getH() {
        return h;
    }

    private void setH(double h) {
        this.h = h;
    }
    
    private double getW() {
        return w;
    }

    private void setW(double w) {
        this.w = w;
    }
    
    @Override
    public String toString() {
        return "rectangle with bottom left corner (" + x + ", " + y + "), "
                + "height " + h + " and width " + w;
    }
    
    /**
     * The left border is the x coordinate of the bottom left corner, 
     * which is just the x coordinate
     * @return left border
     */
    @Override
    public double getLeft() {
        return x;
    }
    
    /**
     * The right border is the x coordinate of the bottom left corner added 
     * with the width
     * @return right border
     */
    @Override
    public double getRight() {
        return x+w;
    }
    
    /**
     * The bottom is the y coordinate of the bottom left corner, which is just y
     * @return bottom border
     */
    @Override
    public double getBottom() {
       return y;
    }

    /**
     * The top is the y coordinate of the bottom left corner added with the 
     * height
     * @return top border
     */
    @Override
    public double getTop() {
        return y + h;
    }

    /**
     * Method to calculate the area of a rectangle (width * height)
     * @return area
     */
    @Override
    public double area() {
        return w * h;
    }

    /**
     * Moves the x and y value by adding dx and dy based on user input
     * @param dx
     * @param dy
     */
    @Override
    public void move(double dx, double dy) {
       x = x + dx;
       y = y + dy;
    }

    
    /**
     * If o==null or this==null then there is no object to compare with.
     * The other if-statements return -1, 1 or 0 based on if the area is bigger 
     * or smaller than the next object
     * @param o
     * @param int which is used for sorting
     */
    @Override
    public int compareTo(GeometricShapes o) {
       if(o==null||this==null) {
           return 0;
       }
       if((area()-o.area() > 0)) {
           return 1;
       } else if((area()-o.area() < 0)) {
           return -1;
       } else {
           return 0;
       }
    }    
}
