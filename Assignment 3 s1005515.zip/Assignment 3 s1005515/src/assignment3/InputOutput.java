/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class InputOutput {
    
    /**
     * Commandloop with all the neccesary commands
     * @param scanner
     * @param array
     */
    public void commandLoop(Scanner scanner, GeometricShapes [] array) {
        Logic logic = new Logic();
        boolean ready = false;
        showMessage();
        while(!ready) {
            System.out.print("> ");
            String command = scanner.next();
            switch(command) {
                case "quit":
                    ready = true;
                    System.out.println("Bye!");
                    break;
                case "show":
                    if(array[0]==null) {
                        System.out.println("There are no elements in the "
                                + "array.");
                    } else {
                        show(array);   
                    }
                    break;
                case "circle":
                    logic.makeCircle(scanner.nextInt(), scanner.nextInt()
                    ,scanner.nextInt(), array);
                    show(array);
                    break;
                 case "rectangle":
                    logic.makeRectangle(scanner.nextInt(), scanner.nextInt()
                    ,scanner.nextInt(), scanner.nextInt(), array);    
                    show(array);
                    break;
                 case "move":
                    array[scanner.nextInt()].move(scanner.nextInt(), 
                            scanner.nextInt());
                    show(array);
                    break;
                 case "remove":
                     if(array[0]==null) {
                        System.out.println("There are no elements to remove.");
                     } else {
                     logic.remove(scanner.nextInt(), array);
                     show(array);   
                     }
                     break;
                 case "sort":
                     logic.sorting(scanner.next(), array);
                     show(array);
                     break;
                 default:
                     System.out.println("ERROR: You did not enter a valid "
                             + "input.");
            }
            scanner.nextLine();
        }
        
    }

    /*
    * A print out message for the user to see all the commands
    */
    private void showMessage() {
        System.out.println("Hi, please enter one of the following commands:");
        System.out.println("quit - stops the program");
        System.out.println("show - lists the geometric objects");
        System.out.println("circle x y r - adds a circle at (x,y) with radius "
                + "r");
        System.out.println("rectangle x y h w - adds a rectangle at (x,y) with "
                + "height h and width w");
        System.out.println("move i dx dy - moves object i over the specified "
                + "distance in x and y direction" );
        System.out.println("remove i - deletes object i");
        System.out.println("sort x/y/area - sorts the objects in the array "
                + "based on x, y or area");
        System.out.println("");
    }
    
    /**
     * Shows all the objects in the GeometricShapes array, and makes use
     * of the .toString() method to print out all the information
     * @param array
     */
    private void show(GeometricShapes[] array) {
        System.out.println("The array now contains: ");
        for(int i = 0; i<array.length  && array[i] != null ;i++) {
            System.out.println(array[i].toString());
        }
                System.out.println("");
    }
    
}
