/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Arrays;

/**
 * 
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Logic {
    
    /**
     * Checks whether there is an empty spot in the array and returns the
     * index. If the array is full, it returns -1.
     * @param array
     * @return index of empty spot
     */
    private int emptySpot(GeometricShapes[] array) {
        for(int i = 0; i < array.length; i++) {
            if(array[i] == null) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Removes an object in the array and shifts all other objects to the left.
     * @param i (index of item to be removed)
     * @param array
     */
    public void remove(int i, GeometricShapes[] array) {
        for(int j = i; j <array.length -1; j++) {
            array[j] = array[j+1];
        }
        array[array.length-1] = null;
    }
    
    /**
     * If input x or y is given, a comparator object with character will be
     * made, else it makes a comparator object without character, meaning it 
     * will sort on the basis of area
     * @param input
     * @param array
     */
    public void sorting(String input, GeometricShapes[] array) {
        if(input.equals("x") || input.equals("y")) {
            Arrays.sort(array, new GeometricShapesComparator(input.charAt(0)));
        } else {
            Arrays.sort(array, new GeometricShapesComparator());
        }
    }
    
    /**
     * Makes a circle object, adds it to the GeometricShapes array
     * @param x (x-coordinate)
     * @param y (y-coordinate)
     * @param r (radius)
     * @param array
     */
    public void makeCircle(int x, int y, int r, GeometricShapes[] array) {
        Circle circle1 = new Circle(x,y,r);
        array[emptySpot(array)] = circle1;
    }
    
    /**
     * Makes a rectangle object, adds it to the GeometricShapes array
     * @param x (x-coordinate)
     * @param y (y-coordinate)
     * @param r (radius)
     * @param h (height)
     * @param array
     */
    public void makeRectangle(int x, int y, int r, int h, GeometricShapes[] array) {
        Rectangle rectangle1 = new Rectangle(x,y,r,h);
        array[emptySpot(array)] = rectangle1;
    }
    
}
