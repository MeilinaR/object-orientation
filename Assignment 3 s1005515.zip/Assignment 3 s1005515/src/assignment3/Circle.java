/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Circle implements GeometricShapes {
    private double x, y, r;

    public Circle(int x, int y, int r) {
       this.x = x;
       this.y = y;
       this.r = r;
    }
    
    private double getR() {
        return r;
    }
    

    private void setR(double r) {
        this.r = r;
    }
    
    private double getX() {
        return x;
    }
    
    private void setX(double x) {
        this.x = x;
    }
   
    private double getY() {
        return y;
    }
    
    
    private void setY(double y) {
        this.y = y;
    }
    
    @Override
    public String toString() {
        return "circle with middle (" + x + ", " + y + ") and radius " + r;
    }

    /**
     * The left border is the middle x coordinate minus the radius
     * @return left border
     */
    @Override
    public double getLeft() {
       return x-r;
    }

    /**
     * The right border is the middle x coordinate plus the radius
     * @return right border
     */
    @Override
    public double getRight() {
        return x+r;
    }

    /**
     * The bottom border is the middle y coordinate minus the radius
     * @return bottom border
     */
    @Override
    public double getBottom() {
        return y-r;
    }

    /**
     * The top border is the middle y coordinate plus the radius
     * @return top border
     */
    @Override
    public double getTop() {
        return y+r;
    }

    /**
     * Method to calculate the area of a circle (pi*radius*radius)
     * @return area
     */
    @Override
    public double area() {
       return Math.PI * r * r;
    }

    /**
     * Moves the x and y value by adding dx and dy based on user input
     * @param dx
     * @param dy
     */
    @Override
    public void move(double dx, double dy) {
        x = x + dx;
        y = y + dy;
    }
    /**
     * If o==null or this==null then there is no object to compare with.
     * The other if-statements return -1, 1 or 0 based on if the area is bigger 
     * or smaller than the next object
     * @param o
     * @param int which is used for sorting
     */
    @Override
    public int compareTo(GeometricShapes o) {
       if(o==null||this==null) {
           return 0;
       }
       if((area()-o.area() > 0)) {
           return 1;
       } else if((area()-o.area() < 0)) {
           return -1;
       } else {
           return 0;
       }
    }   
    
    
}
