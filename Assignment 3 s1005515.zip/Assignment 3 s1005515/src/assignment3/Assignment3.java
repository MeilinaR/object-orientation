/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       InputOutput io = new InputOutput();
       GeometricShapes[] array = new GeometricShapes[10];
       io.commandLoop(scanner, array);
    }
    
}
