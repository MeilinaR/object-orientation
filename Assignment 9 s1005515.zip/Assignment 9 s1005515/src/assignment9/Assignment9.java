/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment9;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Assignment9 extends Application {

    private NumberStringConverter nsc = new NumberStringConverter();
    private IntegerProperty sum = new SimpleIntegerProperty();

    @Override
    public void start(Stage primaryStage) {

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(20);
        root.setVgap(10);

        IntegerProperty value1 = new SimpleIntegerProperty();
        IntegerProperty value2 = new SimpleIntegerProperty();
        IntegerProperty value3 = new SimpleIntegerProperty();
        IntegerProperty value4 = new SimpleIntegerProperty();

        SimpleDoubleProperty outVal1 = new SimpleDoubleProperty();
        SimpleDoubleProperty outVal2 = new SimpleDoubleProperty();
        SimpleDoubleProperty outVal3 = new SimpleDoubleProperty();
        SimpleDoubleProperty outVal4 = new SimpleDoubleProperty();

 
        StringBinding output1 = outVal1.asString();
        StringBinding output2 = outVal2.asString();
        StringBinding output3 = outVal3.asString();
        StringBinding output4 = outVal4.asString();

        Label label1 = new Label();
        label1.textProperty().bind(output1);

        Label label2 = new Label();
        label2.textProperty().bind(output2);

        Label label3 = new Label();
        label3.textProperty().bind(output3);

        Label label4 = new Label();
        label4.textProperty().bind(output4);

        TextField textField1 = new TextField();
        textField1.textProperty().bindBidirectional(value1, nsc);
        textField1.textProperty().addListener(
                new ChangeListener<String>() {
            @Override
            public void changed(
                    ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {
                if (!newValue.matches("[1-9]\\d{0,3}")) {
                    textField1.setText(oldValue);
                }
                sum.bind(value1.add(value2).add(value3.add(value4)));
                outVal1.bind(value1.add(0f).divide(sum.add(0f)));
            }

        });

        TextField textField2 = new TextField();
        textField2.textProperty().bindBidirectional(value2, nsc);
        textField2.textProperty().addListener(
                new ChangeListener<String>() {
            @Override
            public void changed(
                    ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {
                if (!newValue.matches("[1-9]\\d{0,3}")) {
                    textField2.setText(oldValue);
                }
                sum.bind(value1.add(value2).add(value3.add(value4)));
                outVal2.bind(value2.add(0f).divide(sum.add(0f)));
            }

        });
        TextField textField3 = new TextField();
        textField3.textProperty().bindBidirectional(value3, nsc);
        textField3.textProperty().addListener(
                new ChangeListener<String>() {
            @Override
            public void changed(
                    ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {
                if (!newValue.matches("[1-9]\\d{0,3}")) {
                    textField3.setText(oldValue);
                }
                sum.bind(value1.add(value2).add(value3.add(value4)));
                outVal3.bind(value3.add(0f).divide(sum.add(0f)));
            }

        });

        TextField textField4 = new TextField();
        textField4.textProperty().bindBidirectional(value4, nsc);
        textField4.textProperty().addListener(
                new ChangeListener<String>() {
            @Override
            public void changed(
                    ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {
                if (!newValue.matches("[1-9]\\d{0,3}")) {
                    textField4.setText(oldValue);
                }
                sum.bind(value1.add(value2).add(value3.add(value4)));
                outVal4.bind(value4.add(0f).divide(sum.add(0f)));

            }

        });

        root.add(label1, 1, 1);
        root.add(label2, 1, 2);
        root.add(label3, 1, 3);
        root.add(label4, 1, 4);

        root.add(textField1, 0, 1);
        root.add(textField2, 0, 2);
        root.add(textField3, 0, 3);
        root.add(textField4, 0, 4);

        Scene scene = new Scene(root, 300, 300);

        primaryStage.setScene(scene);

        primaryStage.show();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
