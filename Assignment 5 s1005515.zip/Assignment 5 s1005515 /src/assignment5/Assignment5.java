/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import static assignment5.ExpressionFactory.*;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Assignment5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BaseExpr e1 = add(mul(con(2), con(3)), var("a"));
        Map<String, Double> store = new HashMap();

        store.put("a", 1.0);
        System.out.print("a = " + store.get("a") + "\n");
        System.out.println(e1 + " becomes " + e1.partialEval() + " becomes "
                + e1.eval(store));
        System.out.println(" ");

        BaseExpr e2 = mul(add(neg(con(3)), con(3)), var("b"));
        store.put("b", 2.0);
        System.out.print("b = " + store.get("b") + "\n");
        System.out.println(e2 + " becomes " + e2.partialEval() + " becomes "
                + e2.eval(store));
        System.out.println(" ");

        BaseExpr e3 = mul(add(con(0), con(2)), var("c"));
        store.put("c", 3.0);
        System.out.print("c = " + store.get("c") + "\n");
        System.out.println(e3 + " becomes " + e3.partialEval() + " becomes "
                + e3.eval(store));
        System.out.println(" ");

        BaseExpr e4 = add(mul(con(1), con(0)), var("d"));
        store.put("d", 4.0);
        System.out.print("d = " + store.get("d") + "\n");
        System.out.println(e4 + " becomes " + e4.partialEval() + " becomes "
                + e4.eval(store));
        System.out.println(" ");

        BaseExpr e5 = add(mul(neg(con(1)), con(1)), var("e"));
        store.put("e", 5.0);
        System.out.print("e = " + store.get("e") + "\n");
        System.out.println(e5 + " becomes " + e5.partialEval() + " becomes "
                + e5.eval(store));
        System.out.println(" ");

        BaseExpr e6 = mul(add(con(9), con(6)), var("f"));
        store.put("f", 6.0);
        System.out.print("f = " + store.get("f") + "\n");
        System.out.println(e6 + " becomes " + e6.partialEval() + " becomes "
                + e6.eval(store));
        System.out.println(" ");

        BaseExpr e7 = mul(add(neg(con(5)), con(2)), var("g"));
        store.put("g", 7.0);
        System.out.print("g = " + store.get("g") + "\n");
        System.out.println(e7 + " becomes " + e7.partialEval() + " becomes "
                + e7.eval(store));
        System.out.println(" ");

        BaseExpr e8 = mul(add(con(4), con(11)), var("h"));
        store.put("h", 8.0);
        System.out.print("h = " + store.get("h") + "\n");
        System.out.println(e8 + " becomes " + e8.partialEval() + " becomes "
                + e8.eval(store));
        System.out.println(" ");

        BaseExpr e9 = mul(add(con(9), con(8)), var("i"));
        store.put("i", 9.0);
        System.out.print("i = " + store.get("i") + "\n");
        System.out.println(e9 + " becomes " + e9.partialEval() + " becomes "
                + e9.eval(store));
        System.out.println(" ");

        BaseExpr e10 = mul(add(neg(con(12)), con(4)), var("j"));
        store.put("j", 10.0);
        System.out.print("j = " + store.get("j") + "\n");
        System.out.println(e10 + " becomes " + e10.partialEval() + " becomes "
                + e10.eval(store));
        System.out.println(" ");

    }

}
