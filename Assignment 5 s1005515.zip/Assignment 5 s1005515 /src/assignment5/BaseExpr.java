/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public abstract class BaseExpr {

    /**
     * Abstract function that evaluates a Base Expression.
     *
     * @param env
     * @return double
     */
    public abstract double eval(Map<String, Double> env);

    /**
     * Abstract function to partially evaluate a Base Expression.
     *
     * @return BaseExpr
     */
    public abstract BaseExpr partialEval();

    public abstract String toString();

}
