/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public abstract class NoArgExpr extends BaseExpr {

    // this class has been left empty on purpose
}
