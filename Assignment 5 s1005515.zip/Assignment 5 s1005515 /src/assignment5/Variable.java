/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Variable extends NoArgExpr {

    private String name;

    public Variable(String name) {
        this.name = name;
    }

    /**
     * Function that returns the name when evaluating the Map
     *
     * @param store
     * @return constant
     */
    @Override
    public double eval(Map<String, Double> store) {
        return store.get(name);
    }

    /**
     * Function that partially evaluates a variable, 'this' object is returned
     *
     * @return BaseExpr
     */
    @Override
    public BaseExpr partialEval() {
        return this;
    }

    @Override
    public String toString() {
        return name;
    }

}
