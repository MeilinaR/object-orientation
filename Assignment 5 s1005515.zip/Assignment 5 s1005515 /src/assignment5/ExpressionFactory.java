/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class ExpressionFactory {

    /**
     * Method that adds two BaseExpr (left, right) with each other
     *
     * @param left
     * @param right
     * @return Add
     */
    public static Add add(BaseExpr left, BaseExpr right) {
        return new Add(left, right);
    }

    /**
     * Method that multiplies two BaseExpr (left, right) with each other
     *
     * @param left
     * @param right
     * @return Mul
     */
    public static Mul mul(BaseExpr left, BaseExpr right) {
        return new Mul(left, right);
    }

    /**
     * Method that yields the negation of a BaseExpr argument
     *
     * @param argument
     * @return Negation
     */
    public static Negate neg(BaseExpr argument) {
        return new Negate(argument);
    }

    /**
     * Method that yields a constant on the basis of a double parameter
     *
     * @param value
     * @return Constant
     */
    public static Constant con(double value) {
        return new Constant(value);
    }

    /**
     * Method that yields a variable on the basis of a String parameter
     *
     * @param name
     * @return
     */
    public static Variable var(String name) {
        return new Variable(name);
    }
}
