/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public abstract class TwoArgExpr extends BaseExpr {

    protected BaseExpr left, right;

    public TwoArgExpr(BaseExpr left, BaseExpr right) {
        this.left = left;
        this.right = right;
    }

}
