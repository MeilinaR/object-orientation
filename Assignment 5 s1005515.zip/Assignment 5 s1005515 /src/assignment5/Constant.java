/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Constant extends NoArgExpr {

    private double constant;

    public Constant(double value) {
        constant = value;
    }

    /**
     * Function that returns the constant when evaluating the Map.
     *
     * @param store
     * @return constant
     */
    @Override
    public double eval(Map store) {
        return constant;
    }

    /**
     * Function that partially evaluates a constant, 'this' object is returned
     *
     * @return this
     */
    @Override
    public BaseExpr partialEval() {
        return this;
    }

    @Override
    public String toString() {
        return String.valueOf(constant);
    }

}
