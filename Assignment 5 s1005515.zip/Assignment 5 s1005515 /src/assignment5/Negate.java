/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Negate extends OneArgExpr {

    public Negate(BaseExpr argument) {
        super(argument);
    }

    /**
     * Function that evaluates the env and returns the negation.
     *
     * @param store
     * @return double
     */
    @Override
    public double eval(Map<String, Double> env) {
        return -1 * argument.eval(env);
    }

    /**
     * Function that partially evaluates a BaseExpr and returns the negation.
     *
     * @return BaseExpr
     */
    @Override
    public BaseExpr partialEval() {
        argument = argument.partialEval();
        if (argument instanceof Constant) {
            return new Constant(-1 * argument.eval(null));
        }
        return this;
    }

    @Override
    public String toString() {
        return "-" + argument;
    }

}
