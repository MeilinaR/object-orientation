/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public abstract class OneArgExpr extends BaseExpr {

    protected BaseExpr argument;

    public OneArgExpr(BaseExpr argument) {
        this.argument = argument;
    }

}
