/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.util.Map;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Mul extends TwoArgExpr {

    public Mul(BaseExpr left, BaseExpr right) {
        super(left, right);
    }

    /**
     * Function that evaluates the left term and the right term in a Map for
     * addition.
     *
     * @param store
     * @return double
     */
    @Override
    public double eval(Map store) {
        return left.eval(store) * right.eval(store);
    }

    /**
     * Function that partially evaluates a BaseExpr.
     *
     * @return BaseExpr
     */
    @Override
    public BaseExpr partialEval() {
        left = left.partialEval();
        right = right.partialEval();
        if (left instanceof Constant && right instanceof Constant) {
            return new Constant(eval(null));
        } else if (right instanceof Constant && right.eval(null) == 0) {
            return right;
        } else if (left instanceof Constant && left.eval(null) == 1) {
            return right;
        } else if (left instanceof Constant && left.eval(null) == 0) {
            return left;
        } else if (right instanceof Constant && right.eval(null) == 1) {
            return left;
        }
        return this;
    }

    @Override
    public String toString() {
        return "(" + left + "*" + right + ")";
    }

}
