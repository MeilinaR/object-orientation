/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment7;

import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class BlackLeaf implements QuadTreeNode {
    private QuadTreeNode parent;

    public BlackLeaf(QuadTreeNode parent) {
        this.parent = parent;
    }

    /**
     * Method that fills a bitmap with black leaves on the basis of their 
     * given x/y/width.
     * @param x
     * @param y
     * @param width
     * @param bitmap
     */
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
       bitmap.fillArea(x, y, width, true);
    }

    /**
     * Writes the black leaf.
     * @param out
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("00");
        } catch (IOException ex) {
            Logger.getLogger(BlackLeaf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
