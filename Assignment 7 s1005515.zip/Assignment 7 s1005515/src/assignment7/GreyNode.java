/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment7;

import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class GreyNode implements QuadTreeNode {
    private QuadTreeNode parent;

    protected QuadTreeNode[] children;
    
    public GreyNode(QuadTreeNode parent) {
        children = new QuadTreeNode[4];
        this.parent = parent;
    }
    
    /**
     * Method that fills a bitmap with grey nodes
     * on the basis of their x/y/width values
     * @param x
     * @param y
     * @param width
     * @param bitmap
     */
    @Override 
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
      children[0].fillBitmap(x, y, width/2, bitmap);
      children[1].fillBitmap(x+(width/2), y, width/2, bitmap);
      children[2].fillBitmap(x+(width/2), y+(width/2), width/2, bitmap);
      children[3].fillBitmap(x, y+(width/2), width/2, bitmap);
    }

    /**
     * Method that writes out a grey node
     * @param out
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("1");
        } catch (IOException ex) {
            Logger.getLogger(GreyNode.class.getName()).log(Level.SEVERE, null, ex);
        }
        for(int i = 0; i<4;i++) {
            children[i].writeNode(out);
        }
    }
    
}
