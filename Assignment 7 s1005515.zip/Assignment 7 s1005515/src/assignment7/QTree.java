package assignment7;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */

public class QTree {

    private QuadTreeNode root;


    public QTree(Reader input) throws IOException {
        root = readQTree(input, null);
    }

    public QTree(Bitmap bitmap) {
        root = bitmap2QTree(0, 0, bitmap.getWidth(), bitmap,null);
    }

    /**
     * Method that fills the bitmap.
     * @param bitmap
     */
    public void fillBitmap(Bitmap bitmap) {
        root.fillBitmap(0, 0, bitmap.getWidth(), bitmap);
    }

    /**
     * Method that writes out the QTree.
     * @param sb
     */
    public void writeQTree(Writer sb) {
        root.writeNode(sb);
    }
    /**
     * Method that reads out the QTree.
     * @param input, parent
     */
    private static QuadTreeNode readQTree(Reader input, QuadTreeNode parent) throws IOException {
        int character = input.read();
        if (character == '1') {
            GreyNode node = new GreyNode(parent);
            for (int i = 0; i < 4; i++) {
                node.children[i] = readQTree(input, node);
            }
            return node;
        }
        if (character == '0') {
            if (input.read() == '1') {
                WhiteLeaf leaf = new WhiteLeaf(parent);
                return leaf;
            } else {
                BlackLeaf leaf = new BlackLeaf(parent);
                return leaf;
            }
        }
        return null;
    }

    /**
     * Method that converts the bitmap to a QTree.
     * @param x
     * @param y
     * @param width
     * @param bitmap
     * @param parent
     * @return QTree
     */
    public static QuadTreeNode bitmap2QTree(int x, int y, int width, Bitmap bitmap
    , QuadTreeNode parent) {
        if(!checkColour(x,y,width,bitmap)) {
            GreyNode node = new GreyNode(parent);
            node.children[0] = bitmap2QTree(x, y, width/2, bitmap, node);
            node.children[1] = bitmap2QTree(x+(width/2), y, width/2, bitmap, node);
            node.children[2] = bitmap2QTree(x+(width/2), y+(width/2), width/2, bitmap, node);
            node.children[3] = bitmap2QTree(x, y+(width/2), width/2, bitmap, node);
            return node;  
        } else {
            if(!bitmap.getBit(x, y)) {
                WhiteLeaf leaf = new WhiteLeaf(parent);
                return leaf;
            } else {
                BlackLeaf leaf = new BlackLeaf(parent);
                return leaf;
            }
        }
    }
    
    /**
     * Method that checks the colour of a bit in a bitmap
     * @param x
     * @param y
     * @param width
     * @param bitmap
     * @return true/false
     */
    private static boolean checkColour(int x, int y, int width, Bitmap bitmap) {
        boolean colour = bitmap.getBit(x, y);
        for(int i = 0; i<width;i++) {
            for(int j = 0; j<width; j++) {
                if(colour!=bitmap.getBit(x+i, y+j))
                    return false;
            }
        }
        return true;
    }

}
