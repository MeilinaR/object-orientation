/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment7;

import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class WhiteLeaf implements QuadTreeNode {
    private QuadTreeNode parent;
    
    public WhiteLeaf(QuadTreeNode parent) {
        this.parent = parent;
    }

    /**
     * Methods that fills the bitmap with white leaves on the basis of 
     * their x/y/width values.
     * @param x
     * @param y
     * @param width
     * @param bitmap
     */
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
       bitmap.fillArea(x, y, width, false);
    }

    /**
     * Writer that writes out the white leaf.
     * @param out
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("01");
        } catch (IOException ex) {
            Logger.getLogger(WhiteLeaf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
