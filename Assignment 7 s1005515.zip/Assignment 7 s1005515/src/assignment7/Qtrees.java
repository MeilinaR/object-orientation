package assignment7;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;


/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */


public class Qtrees {

    public static void main(String[] args) throws IOException {
        String test_tekst = "10011010001010010001010101100011000101000000";
        StringReader input = new StringReader(test_tekst);
        QTree qt = new QTree( input);
        Bitmap bitmap = new Bitmap(8, 8);
        qt.fillBitmap( bitmap );
        System.out.println(bitmap);
       
        QTree qt2 = new QTree(bitmap);
        OutputStreamWriter osw = new OutputStreamWriter(System.out);
        qt2.writeQTree(osw);
        osw.close();
    }

}
