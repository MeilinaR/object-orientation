package assignment7;

import java.io.Writer;

/**
 *
 * @author Sjaak Smetsers
 * @version 11-03-2016
 */


/*
    Meilina Reksoprodjo (s1005515)
*/

public interface QuadTreeNode {

    /**
     * Method that fills a bitmap on the basis of the x/y/width.
     * @param x
     * @param y
     * @param width
     * @param bitmap
     */
    public void fillBitmap( int x, int y, int width, Bitmap bitmap );

    /**
     * Method that writes out a node.
     * @param out
     */
    public void writeNode( Writer out );
}
