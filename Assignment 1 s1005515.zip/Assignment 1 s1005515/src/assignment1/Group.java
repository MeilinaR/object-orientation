/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Group {
    private Student[] students;
    private static Scanner scanner;
    private static Group group;

    
    public Group(int size) {
        students = new Student[size];
    }
    
    public Group() {
        
    }
    
    /**
     * Method that creates a group ('list') of students (with their first names, 
     * last names and student numbers) on the basis of user input.
     * @param input
     * @param size (array)
     */
    public void makeGroup() {
        scanner = new Scanner(System.in);
        System.out.println("Please enter the group size:");
        int input = scanner.nextInt();
        group = new Group(input);
        System.out.println("Type the student number of the student, followed by "
                + "their first and last name");
           for (int i = 0; i < group.sizeGroup(); i++) {
            System.out.print("Student #"+(i+1)+": ");
            int studentNr = scanner.nextInt();
            String firstName = scanner.next();
            String lastName = scanner.nextLine().substring(1);
            //System.out.print("Student nr: ");
            //int studentNr = scanner.nextInt();
            Student student = new Student(firstName, lastName, studentNr);
            group.changeIndexOfStudent(student, i);
        }
        System.out.println("\nThe group now contains: \n" + group.toString());
    }
    
    /**
     * Method in which the group of students (with their first names, last names
     * and student numbers) can be altered, on the basis of
     * user input.
     * @param input
     * @param size (array)
     */
    public void changeGroup() {
       boolean ready = false;
        while (!ready) {
            System.out.println("Do you want to change your group? Type the "
                    + "student nr to continue"
                    + " or type a negative number to stop.");
            int userInput = scanner.nextInt();
            if (userInput >=0) {
                Student student = group.getStudentId(userInput);
                if (student==null)
                    return;
                System.out.println("Can you give the first and last name of "
                        + "your students?");
                student.firstName = scanner.next();
                student.lastName = scanner.nextLine().substring(1);
                ready = true;
            } else {
                System.out.println("Bye!");
                ready = true;
            }
            
        }
          System.out.println("\nThe group now contains: \n" + group.toString());
    }

    /**
     * Changes the index (i) of a student in the array of students.
     * @param student
     * @param i
     */
    public void changeIndexOfStudent(Student student, int i) {
        students[i] = student; 
    }
    
    /**
     * Changes the first name, last name and student number of a student in the
     * array of students.
     * @param newFirstName
     * @param newLastName
     * @param studentNr
     */
    public void changeStudent(String newFirstName, String newLastName, int studentNr) {
        for(Student student : students) {
            if(studentNr==student.studentNr) {
                student.firstName = newFirstName;
                student.lastName = newLastName;
                student.studentNr = studentNr;
            }
        }
    }
    
    /**
     * Gets the student id from a student that is present in the student array.
     * @param studentNr
     * @return
     */
    public Student getStudentId(int studentNr) {
        for(Student student : students) {
            if (student.studentNr == studentNr) {
                return student;
            }
        }
        return null;
    }
    
    /**
     * Returns the size of the array of students.
     * @return
     */
    public int sizeGroup() {
        return students.length;
    }
    
    @Override
    public String toString() {
        String group = "";
        for(Student student: students) {
            group = group + student + '\n';
        }
        return group;
    }
    
}
