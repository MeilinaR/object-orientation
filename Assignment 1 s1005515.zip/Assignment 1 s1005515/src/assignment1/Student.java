/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */

public class Student {
    
    /**
    * Sidenote: I am aware of the fact that the attributes in here are public,
    * I did this because otherwise I could not access them from the Group.java
    * class.
    */
    
    public String firstName; 
    public String lastName;
    public int studentNr;
    
    public Student(String firstName, String lastName, int studentNr) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentNr = studentNr;
    }
    
    /**
     * Method in which the first name and the last name of a student can be
     * altered.
     * @param newFirstName
     * @param newLastName
     */
    public void changeStudent(String newFirstName, String newLastName) {
        this.firstName = newFirstName;
        this.lastName = newLastName;
    }
    
    @Override
    public String toString() {
        return firstName + " " + lastName + ", s" + studentNr;
    }
    
}
