/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class OpenQuestion extends Question {

    private String question, answer;
    private int score;

    public OpenQuestion(String question, String answer, int score) {
        this.question = question;
        this.answer = answer;
        this.score = score;
    }

    public OpenQuestion(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    /**
     * Boolean which checks if the candidate answer equals the correct answer
     * for an open question.
     *
     * @param candidateAnswer
     * @return
     */
    @Override
    public boolean isCorrect(String candidateAnswer) {
        if (answer.equalsIgnoreCase(candidateAnswer)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return question;
    }

}
