/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

import java.util.Arrays;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class MultipleChoiceQuestion extends Question {

    private String question;
    private String[] answers;
    private int correctAnswer, score;

    public MultipleChoiceQuestion(String question, String[] answers,
            int correctAnswer, int score) {
        this.question = question;
        this.answers = answers;
        this.correctAnswer = correctAnswer;
        this.score = score;

    }

    public MultipleChoiceQuestion(String question, String[] answers,
            int correctAnswer) {
        this.question = question;
        this.answers = answers;
        this.correctAnswer = correctAnswer;

    }

    /**
     * Boolean which checks whether an answer is correct for a multiple choice
     * question. For the MC questions, the user should copy the entire answer
     * (index not included) to answer.
     *
     * @param candidateAnswer
     * @return
     */
    public boolean isCorrect(String candidateAnswer) {
        if (answers[correctAnswer].equalsIgnoreCase(candidateAnswer)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Getter to obtain the question.
     *
     * @return question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * Getter to obtain the answers.
     *
     * @return answers
     */
    public String[] getAnswers() {
        return answers;
    }

    @Override
    public String toString() {
        String output = " ";
        System.out.println(question);
        for (int i = 0; i < answers.length; i++) {
            output += i + ") " + answers[i] + " \n";
        }
        return output;

    }
}
