/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Quiz {

    private List<Question> questions = new LinkedList<>();
    private List<Question> mistakes = new LinkedList<>();
    private String[] answers;

    private Scanner scanner = new Scanner(System.in);
    private int scoreRound1, scoreRound2 = 0;

    public Quiz() {
        this.scoreRound1 = 0;
        this.scoreRound2 = 0;

    }

    /**
     * Method to start the quiz, which is called on in Assignment4.java.
     */
    public void startQuiz() {
        Quiz quiz = new Quiz();
        quiz.message();
        quiz.askQuestions();
    }

    /**
     * Displays introductory message for the user.
     */
    public void message() {
        System.out.println("Welcome to the Object Orientation quiz!");
        System.out.println("You will be given 5 questions to answer and"
                + "there are 3 different types of questions.");
        System.out.println("There are open questions, multiple-choice questions"
                + " and this-or-that questions.");
        System.out.println("Let's start.");

    }

    /**
     * A series of 5 questions which will be asked to the user.
     */
    public void quizQuestions() {
        questions.add(new OpenQuestion("What is the complexity of a binary "
                + "search?", "O(log N)", 2));
        questions.add(new OpenQuestion("What is the minimal amount of construc"
                + "tors for a Java class?", "0"));
        questions.add(new MultipleChoiceQuestion("How do you print \"Hello world\" on a line in Java?", new String[]{"System.out.print(\"Hello world\");", "System.out.println(\"Hello world\");", "cout << \"Hello world\";"}, 1));
        questions.add(new ThisThatQuestion("Yes or No: Is there a difference "
                + "between abstract classes in Java", "yes", "no", 1));
        questions.add(new ThisThatQuestion("Right or wrong: Each class definition "
                + "must have a constructor", "right", "wrong", 2));
    }

    /**
     * Method which asks the questions to the user and yields the user input. I
     * did not implement the method duplicate, but wrote a piece of code that
     * was similar to .duplicate() and somewhat easier to understand.
     */
    public void askQuestions() {
        System.out.println("The questions are: ");
        quizQuestions();
        System.out.println(" ");

        for (Question q : questions) {
            System.out.println(q);

            String userAnswer = scanner.nextLine();

            if (q.isCorrect(userAnswer)) {
                q.setScore(q.getScore());
                scoreRound1 += q.getScore();
            } else {
                mistakes.add(q);
            }
        }

        System.out.println(" ");
        System.out.println("You finished round 1. We will do round 2 with "
                + "the questions you got wrong in the first round.");
        System.out.println(" ");
        startRound2();

        if (mistakes.isEmpty()) {
            System.out.println("Congratulations! You have answered all the "
                    + "answers correctly.");
            System.out.println("Do you want to play again?\n Type 1 if so,"
                    + "else type something else. ");
            if (scanner.nextInt() == 1) {
                startQuiz();
            } else {
                System.out.println("Thanks for playing!");
            }
        }
    }

    /**
     * Method to start round 2 of the quiz.
     */
    private void startRound2() {
        for (Question q : mistakes) {
            System.out.println(q);
            String userAnswer = scanner.nextLine();
            if (q.isCorrect(userAnswer)) {
                q.setScore(q.getScore());
                scoreRound2 += q.getScore();
            }
        }
        System.out.println(" ");
        System.out.println("Your score for round 1 is " + scoreRound1);
        System.out.println("Your score for round 2 is " + scoreRound2);
        System.out.println(" ");
        int total = scoreRound1 + scoreRound2;
        System.out.println("Your total score is " + total);
        System.out.println(" ");

    }
}
