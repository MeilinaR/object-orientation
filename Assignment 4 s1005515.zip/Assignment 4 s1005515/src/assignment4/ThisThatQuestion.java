/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class ThisThatQuestion extends Question {

    private String question, answer1, answer2;
    private int correctAnswer, score;

    public ThisThatQuestion(String question, String answer1, String answer2,
            int correctAnswer, int score) {
        this.question = question;
        this.answer1 = answer1;
        this.answer2 = answer2;
        this.correctAnswer = correctAnswer;
        this.score = score;

    }

    public ThisThatQuestion(String question, String answer1, String answer2,
            int correctAnswer) {
        this.question = question;
        this.answer1 = answer1;
        this.answer2 = answer2;
        this.correctAnswer = correctAnswer;

    }

    /**
     * Boolean which checks if the candidate answer equals one of the answers.
     *
     * @param candidateAnswer
     * @return true/false
     */
    @Override
    public boolean isCorrect(String candidateAnswer) {
        if (answer1.equalsIgnoreCase(candidateAnswer)) {
            return true;
        } else if (answer2.equalsIgnoreCase(candidateAnswer)) {
            return true;
        } else {
            return false;
        }
    }

    private String getQuestion() {
        return question;
    }

    private String getAnswers() {
        return answer1 + " " + answer2;
    }

    private int getCorrectAnswer() {
        return correctAnswer;
    }

    /**
     * Getter to obtain the score
     *
     * @return score
     */
    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        return question;
    }

}
