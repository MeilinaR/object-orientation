/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public abstract class Question {

    static int score = 0;
    private String question, answer;
    private Scanner scanner = new Scanner(System.in);
    private LinkedList<Question> questions = new LinkedList<>();
    private int correct = 0;

    public Question() {

    }

    public Question(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public Question(int score) {
        this.score = score;
    }

    /**
     * Setter to set the score for the questions.
     *
     * @param s
     */
    public void setScore(int s) {
        if (s < 1 || s > 5) {
            score = 3;
        } else {
            score = s;
        }
    }

    /**
     * Getter to obtain the score of a question.
     *
     * @return score
     */
    public int getScore() {
        return this.score;
    }

    /**
     * Abstract method which checks whether an answer is correct, whilst
     * comparing the correct answer with a candidate answer.
     *
     * @param candidateAnswer
     * @return
     */
    public abstract boolean isCorrect(String candidateAnswer);

    /**
     * Method to duplicate the wrong questions in another list.
     */
    public void duplicate() {
        List<Question> mistakes = new LinkedList<>();
        int score1 = 0;
        for (Question q : questions) {
            //System.out.println(q);
            String answer1 = scanner.nextLine();
            if (q.isCorrect(answer)) {
                score += q.getScore();
            } else {
                mistakes.add(q);
            }
        }
        System.out.println(mistakes);
        int score2 = 0;
        for (Question q2 : mistakes) {
            System.out.println(q2);
            String answer2 = scanner.nextLine();

            if (q2.isCorrect(answer)) {
                score += q2.getScore();
            } else {
                break;
            }
        }
    }

    @Override
    public String toString() {
        return question;
    }
}
