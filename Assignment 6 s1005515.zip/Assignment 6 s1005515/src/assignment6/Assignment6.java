package assignment6;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Assignment6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] game = {{1,4,7},{2,0,5},{3,6,8}};
        //int [][] failgame = {{1,4,7},{2,0,5},{6,3,8}}; //failing sliding game
        //int [][] 4game = {{1,5,9,13},{2,6,10,14},{3,7,11,15},{4,8,0,12}}; //A 4*4 game
        int [][] game1 = {{0,4,7} ,{1,2,8} ,{3,5,6}} ; // difficult sliding game, 139 slides
        
        SlidingGame s = new SlidingGame (game1,null);
        //System.out.print(s.getManhat());
        
        Solver solver = new Solver(s);
        System.out.println(solver.solve());
    }
    
}
