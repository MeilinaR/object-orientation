package assignment6;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Meilina Reksoprodjo (s1005515)
 */
public class SlidingGame implements Configuration{

    public static final int N = 3, SIZE = N * N, HOLE = SIZE; //for if you want to solve a 3*3 puzzle.
    //public static final int N = 4, SIZE = N * N, HOLE = SIZE; //for if you want to solve a 4*4 puzzle.
    
    /**
     * The board is represented by a 2-dimensional array; the position of the
     *  hole is kept in 2 variables holeX and holeY.
     */
    private int[][] board;
    private int holeX, holeY;
    private SlidingGame parent;
    private int manhattanDistance;
    
    public SlidingGame(int[][] start, SlidingGame parent) {
        board = new int[N][N];
        for(int x=0; x<start.length; x++) {
            for(int y=0; y<start[0].length; y++) {
                if(start[x][y]==0){
                    holeX = x;
                    holeY = y;
                }
                board[x][y] = start[x][y];
            }
        }
        this.parent = parent;
        this.manhattanDistance = manhattanDistance();
    }
    
    public int getManhat(){
        return manhattanDistance;
    }

    /**
     * Converts a board into a printable representation. The hole is displayed
     * as a space
     *
     * @return the string representation
     */
    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        for (int row = 0; row < N; row++) {
            for (int col = 0; col < N; col++) {
                int puzzel = board[col][row];
                buf.append(puzzel == HOLE ? "  " : puzzel + " ");
            }
            buf.append("\n");
        }
        return buf.toString();
    }

    /**
     * Compares 2 boards with each other.
     * 
     * @param o
     * @return 
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof SlidingGame) {
            SlidingGame other = (SlidingGame) o;
            for(int x=0; x < N; x++) {
                for(int y=0; y<N; y++) {
                    if (other.board[x][y] != this.board[x][y])
                        return false;
                }
            }
            return true;
        } else {
        return false;
        }
    }

    @Override
    public boolean isSolution() {
        for(int x=0; x<N; x++) {
            for(int y=0; y<N; y++) {
                if (x==N-1 & y==N-1) {  //The last spot (bottom right) needs to be empty.
                    return (board[x][y] == 0);
                }
                if (board[x][y] != x + y*N +1)
                    return false;
            }
        }
        return true;
    }

    @Override
    public Collection<? extends Configuration> successors() {
        LinkedList<SlidingGame> list = new LinkedList<>();
        if(holeX-1>=0){ //left
            SlidingGame copy= new SlidingGame(board,this);
            copy.holeX--;
            copy.board[holeX-1][holeY] = 0;
            copy.board[holeX][holeY] = board[holeX-1][holeY];
            list.add(copy);
        }
        if(holeY-1>=0){ //up
            SlidingGame copy= new SlidingGame(board,this);
            copy.holeY--;
            copy.board[holeX][holeY-1] = 0;
            copy.board[holeX][holeY] = board[holeX][holeY-1];
            list.add(copy);
        }
        if(holeX+1<N){ //right
            SlidingGame copy= new SlidingGame(board,this);
            copy.holeX++;
            copy.board[holeX+1][holeY] = 0;
            copy.board[holeX][holeY] = board[holeX+1][holeY];
            list.add(copy);
        }
        if(holeY+1<N){ //down
            SlidingGame copy= new SlidingGame(board,this);
            copy.holeY++;
            copy.board[holeX][holeY+1] = 0;
            copy.board[holeX][holeY] = board[holeX][holeY+1];
            list.add(copy);
        }
        return list;
    }

    /**
     * Compares 2 boards with each other.
     * 
     * @param g
     * @return 
     */
    @Override
    public int compareTo(Configuration g) {
        if (g instanceof SlidingGame) {
            SlidingGame other = (SlidingGame) g;
            return other.getManhat()-this.getManhat();
        }
        return -1;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        for (int x = N-1; x >= 0; x--) {
            for (int y = N-1; y >= 0; y--) {
                hash = 31 * hash + board[x][y];
            }
        }
        return hash;
    }

    @Override
    public List<? extends Configuration> pathFromRoot() {
        List<SlidingGame> list = new LinkedList<>();
        SlidingGame current = this;
        while(current!=null){
            //System.out.println(current);
            list.add(current);
            current = current.parent;
        }
        return list;
    }
    
    
    /**
     * Calculates the Manhattan distance of a current board.
     * 
     * @return 
     */
    public int manhattanDistance(){
        for(int x=0; x < N; x++){
            for(int y=0; y < N; y++){
                int nr = board[x][y];
                if(nr==0){
                    nr = N*N;
                }
                int xDistance = Math.abs((nr-1 % N) - x);
                int yDistance = Math.abs(Math.floorDiv(nr-1, N) - y);
                manhattanDistance += xDistance + yDistance;
            }
        }
        return manhattanDistance;
    }

}
