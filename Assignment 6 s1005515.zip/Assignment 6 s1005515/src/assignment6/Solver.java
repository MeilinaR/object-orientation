package assignment6;

import java.util.*;


/**
 * 
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Solver
{
   // A queue for maintaining graphs that are not visited yet.
    Queue<Configuration> toExamine;
    HashSet<Configuration> hasVisited;

    public Solver( Configuration g ) {
        toExamine = new PriorityQueue();
        toExamine.add(g);
        hasVisited = new HashSet<>();
        hasVisited.add(g);
    }

    /**
     * A skeleton implementation of the solver
     * Once the sliding puzzle has been solved, the program will show the path 
     *  of all intermediate configurations that lead to the solution in the right order.
     *
     * @return a string representation of the solution
     */
    public String solve() {
        while (!toExamine.isEmpty()) {
            Configuration next = toExamine.remove();
            if ( next.isSolution() ) {
                List<? extends Configuration> path = next.pathFromRoot();
                for(int i=path.size()-1; i>=0; i--){
                    System.out.println(path.get(i));
                }
                return "Success!";
            } else {
                for ( Configuration succ : next.successors() ) {
                    if(!hasVisited.contains(succ)) {
                        toExamine.add(succ);
                        hasVisited.add(succ);
                    }
                }
            }
        }
        return "Failure!";
    }
}
