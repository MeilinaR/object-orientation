package assignment6;

import java.util.Collection;
import java.util.List;

/**
 * 
 * @author Meilina Reksoprodjo (s1005515)
 */
public interface Configuration extends Comparable<Configuration> {
    
    /**
     * To obtain the successors for a specific configuration
     *
     * @return a collection of configurations containing the successors
     */
    public  Collection<? extends Configuration> successors();

    /**
     * For marking final / solution configurations.
     * 
     * @return true if a this is a solution, false otherwise
     */
    public boolean isSolution();
        
    /**
     * To build a path from the root configuration to the current one.
     *
     * @return a list of successive configurations from the root to 'this'
     */
    public List<? extends Configuration> pathFromRoot();
}
