/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public final class PlayHangman { 
    
    /**
     * Checks whether the user wants to use their own word or wants to use a 
     *  word from the library
     * @param input 
     */
    public PlayHangman(int input){
        Scanner scanner = new Scanner(System.in);
        if(input==1){
            System.out.println("Please enter a word:");
            String inputWord = scanner.nextLine();
            Gallows hangman = new Gallows(inputWord);
            makeGame(hangman,scanner);
        } else {
            Gallows hangman = new Gallows();
            makeGame(hangman,scanner);
        }
        
    }
    
    /**
     * Makes it possible for the user to play the game. The user can enter a 
     *  letter, and via another function, the letter will be checked for 
     *  presence in the word.
     * @param hangman
     * @param scanner 
     */
    public void makeGame(Gallows hangman, Scanner scanner){
        while(!hangman.getCurrent().toString().equals(hangman.getWord()) 
                && hangman.getStrikes() != 0){
            System.out.println(hangman.toString());
            System.out.println("\nPlease enter a letter:");
            char givenLetter = scanner.next().charAt(0);
            boolean ready = hangman.guessWord(givenLetter);
            if(!ready)
                System.out.println("This letter is not in the word.");
        }
        if(!hangman.getCurrent().toString().equals(hangman.getWord())){
            System.out.println("\nGAME OVER! The word was: "+hangman.getWord());
        } else if(hangman.getStrikes() == 0)
            System.out.println("\nGAME OVER! The word was: "+hangman.getWord());
        else
            System.out.println("\nYou won! The word is: "+hangman.getWord());
    }
}
