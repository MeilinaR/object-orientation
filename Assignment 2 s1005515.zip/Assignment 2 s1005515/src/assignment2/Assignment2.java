/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.Scanner;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Assignment2 { 

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to hangman!\nIf you want to enter a word"
                + " yourself, enter 1, else enter a different number:");
        System.out.println("When you select a different number, we will"
                + " pick a random word for you.");
        int input = scanner.nextInt();
        PlayHangman play = new PlayHangman(input);
    }
    
}
