/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

/**
 *
 * @author Meilina Reksoprodjo (s1005515)
 */
public class Gallows { 
    
    private String word;
    private StringBuilder current;
    private int strikes;
    
    public Gallows() {
        WordReader readWord = new WordReader("words.txt");
        String word = readWord.getWord();
        this.word = word;
        this.current = initCurrent();
        this.strikes = 11;
        
    }
    
    public Gallows(String word) {
        this.word = word;
        this.current = initCurrent();
        this.strikes = 11;
        
    }
    
    public String getWord() {
        return word;
    }
    
    public String setWord(String word) {
        return this.word = word;
    }
    
    public StringBuilder getCurrent() {
        return current;
    }
    
    public StringBuilder setInput(StringBuilder current) {
        return this.current = current;
    }
    
    public int getStrikes() {
        return strikes;
    }
    
    public int setStrikes(int strikes) {
        return this.strikes = strikes;
    }
    
    
    /**
     * Builds the first version of the StringBuilder (only dots).
     * @return currentString
     */
    public StringBuilder initCurrent(){
        StringBuilder inputDots= new StringBuilder(word.length());
        for(int i = 0; i<word.length(); i++){
            inputDots.append('.');
        }
        return inputDots;
    }
    
    /**
     * In this function, the StringBuilder will be changed accordingly with
     * the user's input.
     * @param givenLetter
     * @return ready
     */
   public boolean guessWord(char givenLetter){
        boolean ready = false;
        for(int i = 0; i<word.length(); i++){
            if(word.charAt(i)==givenLetter){
                current.setCharAt(i, givenLetter);
                ready = true;
            }
        }
        if(!ready){
            strikes--;
        }
        return ready;
    }
    
    @Override
    public String toString() {
        return "\nYour current guessed word is: " + current + " and you have " +
                strikes + " strikes left";
    }
    
    
    
}
