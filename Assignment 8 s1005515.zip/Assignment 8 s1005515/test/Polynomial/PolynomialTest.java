/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polynomial;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;


/**
 * @author Meilina Reksoprodjo (s1005515) 
 */

public class PolynomialTest {
    
    public PolynomialTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        
    }

    /** Tests the toString method by comparing instances and results 
     * with each other.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        
        Polynomial instance1 = new Polynomial("3 2 2 3");
        Polynomial instance2 = new Polynomial("2 2 2 3");
        Polynomial instance3 = new Polynomial("8 2 6 3");
        
        String expResult1 = "3,000000x^2 + 2,000000x^3";
        String expResult2 = "2,000000x^2 + 2,000000x^3";
        String expResult3 = "8,000000x^2 + 6,000000x^3";
        
        String result1 = instance1.toString();
        String result2 = instance2.toString();
        String result3 = instance3.toString();
        
        assertEquals(expResult1, result1);
        assertEquals(expResult2, result2);
        assertEquals(expResult3, result3);
    }

    /** Tests the plus method by adding polynomials with instances, and 
     * consecutively compares and checks if it matches with the expected result.
     */
    @Test
    public void testPlus() {
        System.out.println("plus");
        //test case 1
        Polynomial b = new Polynomial("2 2 1 3");
        Polynomial instance1 = new Polynomial("1 1 -2 2 1 3");
        String expResult1 = "1,000000x + 2,000000x^3";
        instance1.plus(b);
        String result1 = instance1.toString();
        assertEquals(expResult1, result1);
        
        //test case 2
        Polynomial c = new Polynomial("-4 1 2 5");
        Polynomial instance2 = new Polynomial("-6 1 2 3 -1 5");
        String expResult2 = "-10,000000x + 2,000000x^3 + 1,000000x^5";
        instance2.plus(c);
        String result2 = instance2.toString();
        assertEquals(expResult2, result2);
        
        //test case 3
        Polynomial d = new Polynomial("1 2 3 4");
        Polynomial instance3 = new Polynomial("1 1 2 3");
        String expResult3 = "1,000000x + 1,000000x^2 + 2,000000x^3 + 3,000000x^4";
        instance3.plus(d);
        String result3 = instance3.toString();
        assertEquals(expResult3, result3);
    }

    /** Tests the min method by subtracting polynomials from instances, and 
     * consecutively compares and checks if it matches with the expected result.
     */
    @Test
    public void testMinus() {
        System.out.println("minus");
        //test case 1
        Polynomial b = new Polynomial("2 2 1 3");
        Polynomial instance1 = new Polynomial("1 1 -2 2 1 3");
        String expResult1 = "1,000000x + -4,000000x^2";
        instance1.minus(b);
        String result1 = instance1.toString();
        assertEquals(expResult1, result1);
        
        //test case 2
        Polynomial c = new Polynomial("-4 1 2 5");
        Polynomial instance2 = new Polynomial("-6 1 2 3 -1 5");
        String expResult2 = "-2,000000x + 2,000000x^3 + -3,000000x^5";
        instance2.minus(c);
        String result2 = instance2.toString();
        assertEquals(expResult2, result2);
        
        //test case 3
        Polynomial d = new Polynomial("1 2 3 4");
        Polynomial instance3 = new Polynomial("1 1 2 3");
        String expResult3 = "1,000000x + -1,000000x^2 + 2,000000x^3 + -3,000000x^4";
        instance3.minus(d);
        String result3 = instance3.toString();
        assertEquals(expResult3, result3);
    }

    /** Tests the times method by multiplying polynomials with instances, and 
     * consecutively compares and checks if it matches with the expected result.
     */
    @Test
    public void testTimes() {
        System.out.println("times");
        //test case 1
        Polynomial b = new Polynomial("4 2 -5 1");
        Polynomial instance1 = new Polynomial("3 2");
        String expResult1 = "-15,000000x^3 + 12,000000x^4";
        instance1.times(b);
        String result1 = instance1.toString();
        assertEquals(expResult1, result1);
        
        //test case 2
        Polynomial c = new Polynomial("2 2 3 1");
        Polynomial instance2 = new Polynomial("4 1 -5 3");
        String expResult2 = "12,000000x^2 + 8,000000x^3 + -15,000000x^4 + -10,000000x^5";
        instance2.times(c);
        String result2 = instance2.toString();
        assertEquals(expResult2, result2);
        
        //test case 3
        Polynomial d = new Polynomial("1 2 3 4");
        Polynomial instance3 = new Polynomial("3 1");
        String expResult3 = "3,000000x^3 + 9,000000x^5";
        instance3.times(d);
        String result3 = instance3.toString();
        assertEquals(expResult3, result3);
    }

    /** Checks whether a polynomial matches an Object of the form Polynomial.
     */
      
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object other_poly = new Polynomial("4 4");
        Polynomial instance = new Polynomial("4 4");
        boolean expResult = true;
        boolean result = instance.equals(other_poly);
        assertEquals(expResult, result);
    }
    
}
